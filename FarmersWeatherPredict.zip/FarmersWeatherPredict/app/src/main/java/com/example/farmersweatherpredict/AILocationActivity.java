package com.example.farmersweatherpredict;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.MapView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Query;

public class AILocationActivity extends AppCompatActivity {

    // ...

    // Replace "YOUR_OPENWEATHER_API_KEY" with your actual OpenWeather API key
    private static final String OPEN_WEATHER_API_KEY = "66f7b80855c74b68cda49d8195690096";
    // Replace "YOUR_GOOGLE_MAPS_API_KEY" with your actual Google Maps API key
    private static final String GOOGLE_MAPS_API_KEY = "YAIzaSyCM2eJu3mU_0joKVRBoFSp1cakLCm56Oco";

    // Retrofit instance for making API requests
    private Retrofit retrofit;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ailocation);

        // Initialize Retrofit
        retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // ... (other initialization code)

        // Set click listener for the "Fetch Weather Information" button
        View btnOpenWeather = null;
        btnOpenWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Perform the logic to fetch weather information
                fetchWeatherInformation();
            }
        });

        // ... (other code)
    }

    // Add this method to fetch weather information from OpenWeather API
    private void fetchWeatherInformation() {
        // Replace with the actual latitude and longitude of the user's location
        double latitude = 37.7749;
        double longitude = -122.4194;

        OpenWeatherService openWeatherService = retrofit.create(OpenWeatherService.class);
        Call<WeatherResponse> call = openWeatherService.getWeather(
                latitude,
                longitude,
                OPEN_WEATHER_API_KEY
        );

        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherResponse weatherResponse = response.body();
                    showWeatherPopup(weatherResponse);
                } else {
                    Toast.makeText(AILocationActivity.this, "Failed to fetch weather information", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                Toast.makeText(AILocationActivity.this, "Failed to fetch weather information", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Add this method to show a pop-up with weather information
    private void showWeatherPopup(WeatherResponse weatherResponse) {
        // Get temperature and weather description from the response
        double temperature = weatherResponse.getMain().getTemp();
        String description = weatherResponse.getWeather().get(0).getDescription();

        // Create an AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Weather Information");
        builder.setMessage("Temperature: " + temperature + "°C\nDescription: " + description);
        builder.setPositiveButton("Show Farming Tips", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the "Show Farming Tips" button click
                // You can add code here to show farming tips
                Toast.makeText(AILocationActivity.this, "Showing Farming Tips", Toast.LENGTH_SHORT).show();
                // Add your logic to display farming tips based on weather conditions
            }
        });
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // ... (other methods)

    // Define the OpenWeatherService interface
    interface OpenWeatherService {

        Call<WeatherResponse> getWeather(double latitude, double longitude, String openWeatherApiKey);
    }
}
